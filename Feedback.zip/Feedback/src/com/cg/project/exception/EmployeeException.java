package com.cg.project.exception;

public class EmployeeException extends Exception  {

	private static final long serialVersionUID = 726264577455921591L;

	public EmployeeException(String message) 
	{
		
		super(message);
	}
}
